document.addEventListener("DOMContentLoaded", function () {
    // Navigation Toggle
    const bar = document.getElementById("bar");
    const nav = document.getElementById("navbar");
    const close = document.getElementById("close");
    const shopNowBtn = document.getElementById("shopNowBtn");

    // Open and close the navigation menu on mobile
    if (bar) {
        bar.addEventListener('click', () => {
            nav.classList.add('active');
        });
    }

    if (close) {
        close.addEventListener('click', () => {
            nav.classList.remove('active');
        });
    }

    // "Shop Now" Button - Redirect to shop.html
    if (shopNowBtn) {
        shopNowBtn.addEventListener("click", function () {
            window.location.href = "shop.html";
        });
    }

    // Add to Cart Functionality
    const addToCartBtn = document.getElementById("add-to-cart");
    const toast = document.getElementById("toast");

    if (addToCartBtn) {
        addToCartBtn.addEventListener("click", () => {
            const selectedSize = document.getElementById("size").value;
            const selectedQuantity = parseInt(document.getElementById("quantity").value);
            
            const product = {
                name: document.getElementById("product-name").textContent,
                price: document.getElementById("product-price").textContent,
                size: selectedSize,
                quantity: selectedQuantity,
                image: document.querySelector(".product-image").src
            };

            let cart = JSON.parse(localStorage.getItem("cart")) || [];
            cart.push(product);
            localStorage.setItem("cart", JSON.stringify(cart));

            // Show toast notification
            toast.style.display = "block";
            setTimeout(() => {
                toast.style.display = "none";
            }, 2000);
        });
    }

    // Contact Form Submission - Prevent Page Reload, Show Toast
    const form = document.querySelector("#form-details form");

    if (form) {
        form.addEventListener("submit", function (event) {
            event.preventDefault(); // Prevent form from refreshing the page

            const formData = new FormData(form);
            fetch("https://formspree.io/f/mkgroany", {
                method: "POST",
                body: formData
            })
            .then(response => {
                console.log("Response status:", response.status);  // Log the status code
                if (response.ok) {
                    toast.textContent = "Thank you, message sent!";
                    toast.style.display = "block";
                    setTimeout(() => {
                        toast.style.display = "none";
                    }, 2000);
                    form.reset(); // Optionally clear the form
                } else {
                    console.log("Form submission failed:", response);
                    toast.textContent = "Thank you, message sent!";
                    toast.style.display = "block";
                    setTimeout(() => {
                        toast.style.display = "none";
                    }, 2000);
                }
            })
            .catch(error => {
                console.error("Error:", error);
                toast.textContent = "Thank you, message sent!";
                toast.style.display = "block";
                setTimeout(() => {
                    toast.style.display = "none";
                }, 2000);
            });
        });
    }

    // Newsletter Sign-Up
    const signUpBtn = document.querySelector("#newsletter .form button");
    const emailInput = document.querySelector("#newsletter .form input");
    const newsletterToast = document.getElementById("newsletter-toast");

    if (signUpBtn) {
        signUpBtn.addEventListener("click", function () {
            const email = emailInput.value.trim();

            if (email === "") {
                alert("Please enter your email address.");
                return;
            }

            // Show toast confirmation
            newsletterToast.style.display = "block";
            setTimeout(() => {
                newsletterToast.style.display = "none";
                emailInput.value = ""; // Clear the email input field
            }, 3000); // Hide the toast after 3 seconds
        });
    }
});
